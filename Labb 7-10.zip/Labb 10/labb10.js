// const calc = function(numberOne, numberTwo) {
    // return numberOne + numberTwo
   
    // let bredd = 10;
    // let längd = 15;
    // let höjd  = 10;

    const calc = (bredd, längd, höjd) => console.log(bredd * längd * höjd);
    calc(10, 29, 10);
    calc(1,2,4);

    
 
    const cirkelArea = (diameter) => {
        const radie = diameter / 2;
        console.log(radie * radie * Math.PI);
    }
